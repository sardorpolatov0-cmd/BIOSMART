/**
 * BIOSMART Online — UIController (TUZATILGAN v2.1)
 * Barcha ekranlar, real-time yangilashlar va o'yin oqimi
 */
'use strict';

const ROLE_INFO = {
  parazit:   { label: 'Parazit',        emoji: '🦠', color: '#ff4757', team: 'parazit',  desc: 'Har kecha bir hujayraga hujum qiling' },
  boshliq:   { label: 'Parazit Boshliq',emoji: '👑', color: '#ff6b81', team: 'parazit',  desc: "Parazit jamoangizni boshqaring" },
  bakteriya: { label: 'Bakteriya',       emoji: '🧫', color: '#ff7f50', team: 'parazit',  desc: 'Yashiringan parazit sifatida hujum qiling' },
  virus:     { label: 'Virus',           emoji: '🦠', color: '#ff6348', team: 'parazit',  desc: 'Ikkita hujayrani infeksiyalaysiz' },
  zamburug:  { label: "Zamburug'",       emoji: '🍄', color: '#eccc68', team: 'parazit',  desc: "Ovoz berish natijasini o'zgartiring" },
  immunitet: { label: 'Immunitet',       emoji: '💊', color: '#2ed573', team: 'hujayra', desc: "Har kecha bir o'yinchini himoya qiling" },
  limfotsit: { label: 'Limfotsit',       emoji: '🔬', color: '#1e90ff', team: 'hujayra', desc: "Bir o'yinchining rolini tekshiring" },
  hujayra:   { label: 'Hujayra',         emoji: '🔵', color: '#74b9ff', team: 'hujayra', desc: 'Ovoz bering va parazitlarni toping' },
};

const PARAZIT_ROLES = ['parazit','boshliq','bakteriya','virus','zamburug'];
const isParazit = r => PARAZIT_ROLES.includes(r);

class UIController {
  constructor(rm) {
    this.rm           = rm;
    this._room        = null;
    this._myRole      = null;
    this._privateData = null;
    this._actionDone  = false;
    this._voteDone    = false;
    this._showingRules = false;

    this._initDOM();
  }

  _initDOM() {
    if (!document.getElementById('toast-container')) {
      const tc = document.createElement('div');
      tc.id = 'toast-container';
      document.body.appendChild(tc);
    }
  }

  // ── Ekran navigatsiyasi ───────────────────────────────────────────────────
  show(screenId) {
    document.querySelectorAll('.screen').forEach(s =>
      s.classList.toggle('active', s.id === screenId)
    );
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  toast(msg, type = 'info', duration = 3000) {
    const tc = document.getElementById('toast-container');
    const t  = document.createElement('div');
    t.className = `toast toast-${type}`;
    t.innerHTML = msg;
    tc.appendChild(t);
    requestAnimationFrame(() => t.classList.add('show'));
    setTimeout(() => { t.classList.remove('show'); setTimeout(() => t.remove(), 400); }, duration);
  }

  // ── Landing ekrani ────────────────────────────────────────────────────────
  renderLanding() {
    const profile = this.rm.getProfile();

    const inp = document.getElementById('input-player-name');
    if (inp && profile.name) inp.value = profile.name;

    const s  = profile.stats;
    const el = document.getElementById('stats-grid');
    if (el) el.innerHTML = `
      <div class="stat-box"><span class="snum">${s.played}</span><span class="slbl">O'yinlar</span></div>
      <div class="stat-box"><span class="snum">${s.wins}</span><span class="slbl">G'alabalar</span></div>
      <div class="stat-box"><span class="snum">${s.asParazit}</span><span class="slbl">Parazit</span></div>
      <div class="stat-box"><span class="snum">${s.asHujayra}</span><span class="slbl">Hujayra</span></div>
    `;

    this.show('screen-landing');
  }

  // ── Qoidalar / Yo'riqnoma ekrani ──────────────────────────────────────────
  renderRules() {
    const existing = document.getElementById('rules-overlay');
    if (existing) { existing.remove(); return; }

    const overlay = document.createElement('div');
    overlay.id = 'rules-overlay';
    overlay.innerHTML = `
      <div class="rules-modal">
        <div class="rules-header">
          <h2>📖 Qanday O'ynash?</h2>
          <button class="rules-close" id="close-rules">✕</button>
        </div>
        <div class="rules-body">

          <div class="rules-section">
            <h3>🎯 Maqsad</h3>
            <p><strong style="color:var(--g0)">Hujayralar:</strong> Barcha parazitlarni topib, ovoz bilan o'yindan chiqarib yuboring.</p>
            <p><strong style="color:#ff6b6b">Parazitlar:</strong> Barcha hujayralarni zararlang va ularni o'yindan chiqarib yuboring.</p>
          </div>

          <div class="rules-section">
            <h3>🔄 O'yin Oqimi</h3>
            <div class="flow-steps">
              <div class="flow-step">
                <span class="step-num">1</span>
                <div>
                  <strong>🌙 KECHA — Infeksiya</strong>
                  <p>Parazitlar qurbon tanlaydi. Immunitet himoya qiladi. Limfotsit tekshiradi. Hujayra o'yinchilari kutadi.</p>
                </div>
              </div>
              <div class="flow-step">
                <span class="step-num">2</span>
                <div>
                  <strong>🌅 TONG — Natijalar</strong>
                  <p>Kim o'yindan chiqarilgani e'lon qilinadi va uning roli oshkor bo'ladi.</p>
                </div>
              </div>
              <div class="flow-step">
                <span class="step-num">3</span>
                <div>
                  <strong>☀️ KUNDUZ — Muhokama</strong>
                  <p>Barcha tirik o'yinchilar kim parazit ekanini muhokama qiladi.</p>
                </div>
              </div>
              <div class="flow-step">
                <span class="step-num">4</span>
                <div>
                  <strong>🗳️ OVOZ — Chiqarish</strong>
                  <p>Har kim eng shubhali o'yinchiga ovoz beradi. Ko'p ovoz olgan o'yindan chiqariladi.</p>
                </div>
              </div>
            </div>
          </div>

          <div class="rules-section">
            <h3>🎭 Rollar</h3>
            <div class="roles-grid-rules">
              <div class="role-rule parazit-team">
                <span>🦠</span>
                <div>
                  <strong>Parazit / Boshliq</strong>
                  <p>Har kecha bir hujayrani zararlaydi. Kimligini yashiradi.</p>
                </div>
              </div>
              <div class="role-rule parazit-team">
                <span>🦠</span>
                <div>
                  <strong>Virus</strong>
                  <p>Bir kechada ikkita hujayrani zararlaydi.</p>
                </div>
              </div>
              <div class="role-rule parazit-team">
                <span>🧫</span>
                <div>
                  <strong>Bakteriya</strong>
                  <p>Yashirin parazit — hujum qiladi lekin kamroq shubha uyg'otadi.</p>
                </div>
              </div>
              <div class="role-rule parazit-team">
                <span>🍄</span>
                <div>
                  <strong>Zamburug'</strong>
                  <p>Ovoz natijasini tasodifiy o'zgartiradi (kuchli maxsus qobiliyat).</p>
                </div>
              </div>
              <div class="role-rule hujayra-team">
                <span>💊</span>
                <div>
                  <strong>Immunitet</strong>
                  <p>Har kecha bir o'yinchini parazit hujumidan himoya qiladi.</p>
                </div>
              </div>
              <div class="role-rule hujayra-team">
                <span>🔬</span>
                <div>
                  <strong>Limfotsit</strong>
                  <p>Har kecha bir o'yinchining parazit yoki yo'qligini bilib oladi.</p>
                </div>
              </div>
              <div class="role-rule hujayra-team">
                <span>🔵</span>
                <div>
                  <strong>Hujayra</strong>
                  <p>Oddiy o'yinchi. Muhokama va ovoz orqali g'alaba qozonadi.</p>
                </div>
              </div>
            </div>
          </div>

          <div class="rules-section">
            <h3>👥 O'yinchilar soniga qarab rollar</h3>
            <div class="role-table">
              <div class="rt-header">
                <span>👤 Son</span><span>🦠 P</span><span>🔵 H</span><span>💊 I</span><span>🔬 L</span>
              </div>
              <div class="rt-row"><span>3</span><span>1</span><span>1</span><span>1</span><span>—</span></div>
              <div class="rt-row"><span>4</span><span>2</span><span>1</span><span>1</span><span>—</span></div>
              <div class="rt-row"><span>5</span><span>2</span><span>2</span><span>1</span><span>—</span></div>
              <div class="rt-row"><span>6</span><span>2</span><span>3</span><span>1</span><span>—</span></div>
              <div class="rt-row"><span>7</span><span>3</span><span>2</span><span>1</span><span>1</span></div>
              <div class="rt-row"><span>8</span><span>3</span><span>3</span><span>1</span><span>1</span></div>
              <div class="rt-row"><span>9</span><span>3</span><span>4</span><span>1</span><span>1</span></div>
              <div class="rt-row"><span>10</span><span>4</span><span>4</span><span>1</span><span>1</span></div>
              <div class="rt-row rt-note"><span>11–20</span><span>4</span><span>↑</span><span>1</span><span>1</span></div>
            </div>
            <p style="font-size:.78rem;color:var(--tx2);margin-top:8px">P=Parazit · H=Hujayra · I=Immunitet · L=Limfotsit | 4+ parazitda: boshliq, virus, bakteriya, zamburug' ketma-ket</p>
          </div>

          <div class="rules-section">
            <h3>🏆 G'alaba Sharti</h3>
            <div class="win-conditions">
              <div class="win-card parazit-win-card">
                <span>🦠</span>
                <div>
                  <strong>Parazitlar g'alaba qozonadi</strong>
                  <p>Barcha hujayralar zararlaniб o'yindan chiqarilsa</p>
                </div>
              </div>
              <div class="win-card hujayra-win-card">
                <span>🛡️</span>
                <div>
                  <strong>Hujayralar g'alaba qozonadi</strong>
                  <p>Barcha parazitlar topilиб o'yindan chiqarilsa</p>
                </div>
              </div>
            </div>
          </div>

          <div class="rules-section">
            <h3>⚙️ Qo'shimcha</h3>
            <p>Minimum <strong>3 o'yinchi</strong> kerak. Optimal tajriba: <strong>7–10 kishi</strong>.</p>
            <p>Immunitet va Limfotsitni lobby da yoqish/o'chirish mumkin.</p>
            <p>O'lgan o'yinchi kuzatuvchi sifatida o'yinni kuzatib qoladi.</p>
          </div>

        </div>
        <button class="bio-btn btn-primary" id="close-rules-btn" style="margin:16px auto;display:block;max-width:200px">
          ✅ Tushundim!
        </button>
      </div>
    `;
    overlay.style.cssText = `
      position:fixed;inset:0;z-index:9999;
      background:rgba(2,11,16,0.96);
      display:flex;align-items:flex-start;justify-content:center;
      overflow-y:auto;padding:20px 16px;
    `;
    document.body.appendChild(overlay);

    const closeRules = () => overlay.remove();
    document.getElementById('close-rules')?.addEventListener('click', closeRules);
    document.getElementById('close-rules-btn')?.addEventListener('click', closeRules);
    overlay.addEventListener('click', e => { if (e.target === overlay) closeRules(); });
  }

  // ── Lobby ekrani ──────────────────────────────────────────────────────────
  renderLobby(room) {
    this._room = room;
    const players  = Object.values(room.players || {});
    const iAmHost  = this.rm.isHost(room);
    const allReady = players.length >= 3 && players.every(p => p.ready || p.isHost);
    const myPlayer = this.rm.getMyPlayer(room);

    const el = document.getElementById('lobby-content');
    if (!el) return;

    el.innerHTML = `
      <div class="lobby-code-box">
        <p class="lbl">Xona kodi</p>
        <div class="room-code" id="room-code-display">${room.code}</div>
        <button class="copy-btn" onclick="copyRoomCode()">📋 Nusxalash</button>
        <p class="share-hint">Ushbu kodni do'stlaringizga yuboring!</p>
      </div>

      <div class="lobby-players">
        <h3>👥 O'yinchilar (${players.length}/${room.config?.maxPlayers || 15})</h3>
        <div class="player-list" id="player-list">
          ${players.sort((a,b) => a.joinedAt - b.joinedAt).map(p => `
            <div class="player-row ${p.online === false ? 'offline' : ''}" data-pid="${p.id}">
              <span class="player-avatar">${this._nameEmoji(p.name)}</span>
              <span class="player-name">${p.name}${p.isHost ? ' 👑' : ''}</span>
              <span class="player-status ${p.ready || p.isHost ? 'ready' : 'waiting'}">
                ${p.ready || p.isHost ? '✅ Tayyor' : '⏳ Kutilmoqda'}
              </span>
            </div>
          `).join('')}
        </div>
      </div>

      <div class="lobby-actions">
        ${!iAmHost && !myPlayer?.ready ? `
          <button class="bio-btn btn-primary" id="btn-ready">✅ Tayyor!</button>
        ` : !iAmHost ? `
          <p class="ready-text">✅ Tayyor! Host boshlanishini kuting...</p>
        ` : ''}

        ${iAmHost ? `
          <div class="host-config">
            <h3>⚙️ Sozlamalar</h3>
            <label class="toggle-row">
              <span>💊 Immunitet</span>
              <input type="checkbox" id="cfg-immunit" ${room.config?.includeImmunit !== false ? 'checked' : ''}>
            </label>
            <label class="toggle-row">
              <span>🔬 Limfotsit</span>
              <input type="checkbox" id="cfg-limfotsit" ${room.config?.includeLimfotsit !== false ? 'checked' : ''}>
            </label>
            <p style="font-size:.75rem;color:var(--tx2);margin-top:4px">Rollar o'yinchilar soniga qarab avtomatik taqsimlanadi</p>
          </div>
          <button class="bio-btn btn-primary ${allReady ? '' : 'btn-disabled'}"
                  id="btn-start-game" ${allReady ? '' : 'disabled'}>
            ${allReady ? "🎮 O'yinni boshlash!" : `⏳ O'yinchilar kutilmoqda (${players.length}/3)`}
          </button>
        ` : ''}
      </div>
    `;

    document.getElementById('btn-ready')?.addEventListener('click', () => this.rm.setReady(true));

    document.getElementById('btn-start-game')?.addEventListener('click', async () => {
      if (!allReady) return;
      const config = {
        includeImmunit:   document.getElementById('cfg-immunit')?.checked !== false,
        includeLimfotsit: document.getElementById('cfg-limfotsit')?.checked !== false,
      };
      await window.db.ref(`rooms/${room.code}/config`).update(config);
      const freshSnap = await window.db.ref(`rooms/${room.code}/players`).once('value');
      const freshPlayers = Object.values(freshSnap.val() || {});
      await this.rm.startGame(freshPlayers, config);
    });

    this._updateHeader(room);
    this.show('screen-lobby');
  }

  // ── Rol ekrani ────────────────────────────────────────────────────────────
  renderRoleReveal(room) {
    const me = this.rm.getMyPlayer(room);
    if (!me) return;

    this._myRole = me.role;
    const ri     = ROLE_INFO[me.role] || ROLE_INFO.hujayra;

    let teamInfo = '';
    if (isParazit(me.role)) {
      const teammates = Object.values(room.players || {})
        .filter(p => isParazit(p.role) && p.id !== me.id);
      if (teammates.length > 0) {
        teamInfo = `<div class="team-info">
          <p>🦠 Jamoangiz:</p>
          ${teammates.map(t => `<span class="teammate">${t.name}</span>`).join('')}
        </div>`;
      }
    }

    const screen = document.getElementById('screen-role');
    screen.innerHTML = `
      <div class="role-reveal-wrap">
        <div class="role-glow-bg" style="--gc: ${ri.color}44"></div>
        <p class="role-for">Sizning rolingiz:</p>
        <div class="role-emoji-big">${ri.emoji}</div>
        <h1 class="role-title" style="color:${ri.color}">${ri.label}</h1>
        <p class="role-desc">${ri.desc}</p>
        <div class="role-team-badge ${ri.team === 'parazit' ? 'badge-parazit' : 'badge-hujayra'}">
          ${ri.team === 'parazit' ? '🦠 Parazit Jamoasi' : '🛡️ Hujayra Jamoasi'}
        </div>
        ${teamInfo}
        <p class="role-privacy">🔒 Ekranni boshqalarga ko'rsatmang!</p>
        <p class="role-wait">⏳ Kecha bosqichi ${me.isHost ? '4 soniyada' : 'tez orada'} boshlanadi...</p>
      </div>
    `;
    this.show('screen-role');
  }

  // ── Kecha ekrani ──────────────────────────────────────────────────────────
  renderNight(room) {
    this._actionDone = false;
    const me   = this.rm.getMyPlayer(room);
    const myRl = me?.role;

    if (!me?.alive) {
      this._renderSpectatorNight(room);
      return;
    }

    const screen = document.getElementById('screen-night');
    const alive  = Object.values(room.players || {}).filter(p => p.alive);
    const others = alive.filter(p => p.id !== me.id);

    const needsAction = this._needsNightAction(myRl, room.config);
    if (!needsAction) {
      screen.innerHTML = `
        <div class="night-wait">
          <div class="night-moon">🌙</div>
          <h2>Infeksiya Bosqichi</h2>
          <p>Siz kechada harakat qilmaysiz.</p>
          <p class="night-wait-sub">Boshqa o'yinchilar harakatini kuting...</p>
          <div class="pulse-ring"></div>
        </div>`;
      this.show('screen-night');
      return;
    }

    const roleActions = {
      parazit:   { icon: '🦠', title: 'Qurboningizni tanlang',      hint: 'Qaysi hujayrani infeksiyalaymiz?',       targets: others },
      boshliq:   { icon: '👑', title: 'Hujum maqsadini tanlang',    hint: 'Parazit jamoasi nomidan hujum',          targets: others },
      bakteriya: { icon: '🧫', title: 'Hujum maqsadini tanlang',    hint: 'Yashirin parazit hujumi',               targets: others },
      virus:     { icon: '🦠', title: 'Asosiy nishonni tanlang',    hint: 'Ikkinchi qurbon tasodifiy tanlanadi',    targets: others },
      immunitet: { icon: '💊', title: 'Kimni himoya qilasiz?',       hint: "Tanlangan o'yinchi kechada himoyalanadi", targets: alive },
      limfotsit: { icon: '🔬', title: 'Kimni tekshirasiz?',          hint: "Parazitmi yoki yo'q bilib olasiz",      targets: others },
    };

    const actionKey = isParazit(myRl) ? (myRl === 'zamburug' ? null : myRl) : myRl;
    const ac = roleActions[actionKey] || roleActions.parazit;

    screen.innerHTML = `
      <div class="night-action-panel">
        <div class="night-header">
          <span class="night-icon-big">${ac.icon}</span>
          <h2>${ac.title}</h2>
          <p>${ac.hint}</p>
        </div>
        <div class="target-grid" id="target-grid">
          ${ac.targets.map(t => `
            <button class="target-card" data-id="${t.id}">
              <span class="target-av">${this._nameEmoji(t.name)}</span>
              <span class="target-nm">${t.name}</span>
            </button>
          `).join('')}
          ${isParazit(myRl) ? `
            <button class="target-card target-skip" data-id="skip">
              <span class="target-av">💤</span>
              <span class="target-nm">O'tkazib yuborish</span>
            </button>` : ''}
        </div>
        <p class="privacy-note">📵 Ekranni boshqalarga ko'rsatmang</p>
      </div>
    `;

    screen.querySelectorAll('.target-card').forEach(btn => {
      btn.addEventListener('click', async e => {
        if (this._actionDone) return;
        screen.querySelectorAll('.target-card').forEach(b => b.classList.remove('selected'));
        e.currentTarget.classList.add('selected');
        this._actionDone = true;

        const targetId   = e.currentTarget.dataset.id;
        const actionType = isParazit(myRl) ? 'parazit' : myRl;

        if (targetId !== 'skip') {
          await this.rm.submitNightAction(actionType, targetId);
        }

        setTimeout(() => {
          screen.innerHTML = `
            <div class="night-wait">
              <div class="action-done-icon">✅</div>
              <h2>Harakatiz saqlandi!</h2>
              <p>Boshqa o'yinchilar harakatini kuting...</p>
              <div class="pulse-ring"></div>
            </div>`;
        }, 600);
      });
    });

    this.show('screen-night');
  }

  _renderSpectatorNight(room) {
    const screen = document.getElementById('screen-night');
    screen.innerHTML = `
      <div class="night-wait spectator">
        <div class="night-moon">🌙</div>
        <h2>Infeksiya Bosqichi</h2>
        <p>Siz halok bo'lgansiz. Kuzatuvdasiz.</p>
        <div class="pulse-ring"></div>
      </div>`;
    this.show('screen-night');
  }

  // ── Kecha natijasi ekrani ─────────────────────────────────────────────────
  renderNightResult(room) {
    const result  = room.lastNightResult || {};
    const screen  = document.getElementById('screen-result');
    const alive   = Object.values(room.players || {}).filter(p => p.alive);
    const iAmHost = this.rm.isHost(room);

    let html = `<div class="result-panel">
      <h2 class="result-title">🌅 Tong Natijalari</h2>
      <div class="result-events">`;

    if (result.killed) {
      html += `<div class="result-event ev-death">
        <span>☠️</span>
        <div><strong>${result.killed.name}</strong> infeksiyalandi
          <small>Rol: ${ROLE_INFO[result.killed.role]?.label || '?'}</small>
        </div></div>`;
    }
    if (result.killedSecond) {
      html += `<div class="result-event ev-death">
        <span>🦠</span>
        <div><strong>${result.killedSecond.name}</strong> ham Virus tomonidan infeksiyalandi!
          <small>Rol: ${ROLE_INFO[result.killedSecond.role]?.label || '?'}</small>
        </div></div>`;
    }
    if (!result.killed && !result.killedSecond) {
      if (result.saved) {
        html += `<div class="result-event ev-save"><span>💊</span>
          <div>Immunitet hujumni to'xtatdi — hech kim halok bo'lmadi!</div></div>`;
      } else {
        html += `<div class="result-event ev-safe"><span>😌</span>
          <div>Bu kecha hech kim halok bo'lmadi</div></div>`;
      }
    } else if (result.saved) {
      html += `<div class="result-event ev-save"><span>💊</span>
        <div>Immunitet kimnidir qutqarishga urindi!</div></div>`;
    }

    // Limfotsit natijasi (faqat o'sha o'yinchiga ko'rinadi)
    if (this._privateData?.inspectResult) {
      const { player, isParazit: ip } = this._privateData.inspectResult;
      html += `<div class="result-event ev-inspect">
        <span>🔬</span>
        <div><strong>${player.name}</strong> —
          ${ip ? '<span class="danger-text">⚠️ Parazit jamoasidan!</span>'
               : '<span class="safe-text">✅ Hujayra jamoasidan</span>'}
        </div></div>`;
    }

    html += `</div>
      <div class="alive-count">Tirik: <strong>${alive.length}</strong> o'yinchi</div>`;

    if (iAmHost) {
      html += `
        <div class="auto-advance-bar">
          <div class="auto-bar-fill" id="auto-bar"></div>
        </div>
        <p class="auto-hint">Tahlil bosqichi <span id="auto-countdown">5</span> soniyada boshlanadi</p>
        <button class="bio-btn btn-primary" id="btn-to-day" style="margin-top:8px">☀️ Hoziroq boshlash</button>`;
    } else {
      html += `<p class="wait-host">⏳ Host tahlil bosqichini boshlamoqda...</p>`;
    }

    html += `</div>`;
    screen.innerHTML = html;

    if (iAmHost) {
      // Countdown animatsiya
      let secs = 5;
      const cdEl = document.getElementById('auto-countdown');
      const barEl = document.getElementById('auto-bar');
      if (barEl) barEl.style.transition = `width 5s linear`;
      setTimeout(() => { if (barEl) barEl.style.width = '100%'; }, 50);

      const cdi = setInterval(() => {
        secs--;
        if (cdEl) cdEl.textContent = secs;
        if (secs <= 0) clearInterval(cdi);
      }, 1000);

      document.getElementById('btn-to-day')?.addEventListener('click', async () => {
        clearInterval(cdi);
        await this.rm.advanceToDay();
      });
    }

    this.show('screen-result');
  }

  // ── Kun ekrani ────────────────────────────────────────────────────────────
  renderDay(room) {
    const alive   = Object.values(room.players || {}).filter(p => p.alive);
    const dead    = Object.values(room.players || {}).filter(p => !p.alive);
    const iAmHost = this.rm.isHost(room);
    const screen  = document.getElementById('screen-day');

    screen.innerHTML = `
      <div class="day-panel">
        <div class="day-header">
          <h2>☀️ Tahlil Bosqichi — ${room.round}-tur</h2>
          <p>Muhokama qiling, parazitni toping!</p>
        </div>

        ${this._privateData?.inspectResult ? `
        <div class="inspect-reveal">
          <h3>🔬 Limfotsit Ma'lumoti:</h3>
          <p><strong>${this._privateData.inspectResult.player.name}</strong> —
            ${this._privateData.inspectResult.isParazit
              ? '<span class="danger-text">⚠️ Parazit jamoasidan!</span>'
              : '<span class="safe-text">✅ Hujayra jamoasidan</span>'}
          </p>
        </div>` : ''}

        <div class="status-section">
          <h3>O'yinchilar holati</h3>
          <div class="status-grid">
            ${alive.map(p => `
              <div class="status-card alive">
                <span>${this._nameEmoji(p.name)}</span>
                <span>${p.name}</span>
                <span class="badge-alive">Tirik</span>
              </div>`).join('')}
            ${dead.map(p => `
              <div class="status-card dead">
                <span style="filter:grayscale(1)">${this._nameEmoji(p.name)}</span>
                <span>${p.name}</span>
                <span class="badge-dead">Halok — ${ROLE_INFO[p.role]?.label || '?'}</span>
              </div>`).join('')}
          </div>
        </div>

        <div class="day-log">
          <h3>📋 O'yin Logi</h3>
          <div class="log-list">
            ${Object.values(room.logs || {}).slice(-10).reverse().map(l => `
              <div class="log-item log-${l.type}">
                <span>${l.message}</span>
              </div>`).join('')}
          </div>
        </div>

        ${iAmHost
          ? `<button class="bio-btn btn-primary" id="btn-to-vote">🗳️ Ovoz berish</button>`
          : `<p class="wait-host">⏳ Host ovoz berish bosqichini boshlamoqda...</p>`}
      </div>
    `;

    document.getElementById('btn-to-vote')?.addEventListener('click', () => this.rm.advanceToVote());
    this.show('screen-day');
  }

  // ── Ovoz berish ekrani ────────────────────────────────────────────────────
  renderVote(room) {
    this._voteDone = false;
    const alive  = Object.values(room.players || {}).filter(p => p.alive);
    const me     = this.rm.getMyPlayer(room);
    const screen = document.getElementById('screen-vote');

    if (!me?.alive) {
      screen.innerHTML = `
        <div class="night-wait spectator">
          <h2>🗳️ Ovoz Berish</h2>
          <p>Siz halok bo'lgansiz — ovoz bera olmaysiz.</p>
          <p class="wait-host">⏳ Natijani kuting...</p>
          <div class="pulse-ring"></div>
        </div>`;
      this.show('screen-vote');
      return;
    }

    const candidates = alive.filter(p => p.id !== me.id);

    screen.innerHTML = `
      <div class="vote-panel">
        <h2>🗳️ Ovoz Bering</h2>
        <p>Kim parazit deb o'ylaysiz?</p>
        <div class="vote-targets" id="vote-targets">
          ${candidates.map(p => `
            <button class="vote-btn" data-id="${p.id}">
              <span class="vote-av">${this._nameEmoji(p.name)}</span>
              <span class="vote-nm">${p.name}</span>
            </button>`).join('')}
        </div>
        <div id="vote-status" class="vote-status"></div>
      </div>
    `;

    screen.querySelectorAll('.vote-btn').forEach(btn => {
      btn.addEventListener('click', async e => {
        if (this._voteDone) return;
        screen.querySelectorAll('.vote-btn').forEach(b => b.classList.remove('selected'));
        e.currentTarget.classList.add('selected');
        this._voteDone = true;

        const targetId = e.currentTarget.dataset.id;
        await this.rm.submitVote(targetId);

        const st = document.getElementById('vote-status');
        if (st) st.innerHTML = `<p class="voted-confirm">✅ Ovozingiz qabul qilindi. Natijani kuting...</p>`;
      });
    });

    this.show('screen-vote');
  }

  // ── O'yin tugash ekrani ───────────────────────────────────────────────────
  renderGameOver(room) {
    const { winner, players } = room;
    const isParazitWin = winner === 'parazit';
    const playerArr    = Object.values(players || {});
    const me           = this.rm.getMyPlayer(room);
    const myRl         = me?.role;
    const iWon         = (isParazitWin && isParazit(myRl)) || (!isParazitWin && !isParazit(myRl));

    if (myRl) this.rm.updateStats(iWon, myRl);

    const screen = document.getElementById('screen-gameover');
    screen.innerHTML = `
      <div class="gameover-wrap ${isParazitWin ? 'parazit-win' : 'hujayra-win'}">
        <div class="go-emoji">${isParazitWin ? '🦠' : '🛡️'}</div>
        <h1 class="go-title">${isParazitWin ? "Parazitlar G'alaba!" : "Hujayralar G'alaba!"}</h1>
        <p class="go-subtitle">${isParazitWin
          ? "Barcha hujayralar zararlandi — organizm mag'lub bo'ldi"
          : "Barcha parazitlar yo'q qilindi — immunitet tizimi g'olib!"}</p>
        <div class="my-result ${iWon ? 'i-won' : 'i-lost'}">
          ${iWon ? "🏆 Siz g'alaba qozondingiz!" : '💀 Siz yutqazdingiz'}
        </div>

        <div class="reveal-section">
          <h3>👁️ Barcha Rollar</h3>
          <div class="reveal-grid">
            ${playerArr.map(p => {
              const ri = ROLE_INFO[p.role] || ROLE_INFO.hujayra;
              return `<div class="reveal-card ${!p.alive ? 'rc-dead' : ''}">
                <span class="rc-emoji">${ri.emoji}</span>
                <span class="rc-name">${p.name}</span>
                <span class="rc-role" style="color:${ri.color}">${ri.label}</span>
                ${!p.alive ? '<span class="dead-mark">✕</span>' : ''}
              </div>`;
            }).join('')}
          </div>
        </div>

        <div class="go-actions">
          ${this.rm.isHost(room) ? `<button class="bio-btn btn-primary" id="btn-new-game">🔄 Yangi o'yin</button>` : ''}
          <button class="bio-btn btn-secondary" id="btn-leave">🏠 Chiqish</button>
        </div>
      </div>
    `;

    document.getElementById('btn-new-game')?.addEventListener('click', async () => {
      const updates = {
        [`rooms/${room.code}/status`]:          'lobby',
        [`rooms/${room.code}/round`]:           0,
        [`rooms/${room.code}/nightActions`]:    {},
        [`rooms/${room.code}/votes`]:           null,
        [`rooms/${room.code}/winner`]:          null,
        [`rooms/${room.code}/lastNightResult`]: null,
        [`rooms/${room.code}/logs`]:            null,
        [`rooms/${room.code}/privateData`]:     null,
        [`rooms/${room.code}/voteResolvedAt`]:  null,
      };
      const playerSnap = await window.db.ref(`rooms/${room.code}/players`).once('value');
      playerSnap.forEach(c => {
        updates[`rooms/${room.code}/players/${c.key}/alive`]  = true;
        updates[`rooms/${room.code}/players/${c.key}/role`]   = null;
        updates[`rooms/${room.code}/players/${c.key}/ready`]  = false;
        updates[`rooms/${room.code}/players/${c.key}/votes`]  = 0;
        updates[`rooms/${room.code}/players/${c.key}/protected`] = false;
      });
      await window.db.ref().update(updates);
    });

    document.getElementById('btn-leave')?.addEventListener('click', () => {
      this.rm.stopListening();
      this.rm.roomId = null;
      this._voteDone = false;
      this._actionDone = false;
      this.show('screen-landing');
      this.renderLanding();
    });

    this.show('screen-gameover');
  }

  // ── Kecha harakati kerakmi? ───────────────────────────────────────────────
  _needsNightAction(role, config) {
    if (!role) return false;
    if (isParazit(role) && role !== 'zamburug') return true;
    if (role === 'immunitet' && config?.includeImmunit !== false) return true;
    if (role === 'limfotsit' && config?.includeLimfotsit !== false) return true;
    return false;
  }

  // ── Header yangilash ──────────────────────────────────────────────────────
  _updateHeader(room) {
    const phaseEl = document.getElementById('hdr-phase');
    const roundEl = document.getElementById('hdr-round');
    const aliveEl = document.getElementById('hdr-alive');
    const alive   = Object.values(room?.players || {}).filter(p => p.alive).length;

    const phases = {
      lobby:    '🏠 Lobby',
      roles:    '🎭 Rollar',
      night:    '🌙 Kecha',
      result:   '📊 Natija',
      day:      '☀️ Kunduz',
      vote:     '🗳️ Ovoz',
      gameover: '🏁 Tugadi',
    };
    if (phaseEl) phaseEl.textContent = phases[room?.status] || '—';
    if (roundEl) roundEl.textContent = room?.round || 0;
    if (aliveEl) aliveEl.textContent = alive;
  }

  // ── Nom → Emoji ───────────────────────────────────────────────────────────
  _nameEmoji(name = '') {
    const emojis = ['🧬','⚗️','🔭','🧪','🦴','🧠','❤️','🫁','🫀','🦷','👁️','🧫','🦠','💊','🔬','🩺','🧲','⚡','🌊','🍃'];
    let h = 0;
    for (const c of name) h = (h * 31 + c.charCodeAt(0)) & 0xFFFF;
    return emojis[h % emojis.length];
  }
}

window.UIController = UIController;
window.ROLE_INFO    = ROLE_INFO;
window.isParazit    = isParazit;
