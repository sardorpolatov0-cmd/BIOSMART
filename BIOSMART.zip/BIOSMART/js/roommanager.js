/**
 * BIOSMART Online — RoomManager (TUZATILGAN v2.1)
 * Xona yaratish, qo'shilish va real-time sinxronizatsiya
 */
'use strict';

class RoomManager {
  constructor() {
    this.roomId     = null;
    this.playerId   = null;
    this.playerName = null;
    this._listeners = [];

    this.playerId   = localStorage.getItem('biosmart_player_id')   || this._genId('player');
    this.playerName = localStorage.getItem('biosmart_player_name') || null;
    localStorage.setItem('biosmart_player_id', this.playerId);
  }

  // ── ID generatorlar ──────────────────────────────────────────────────────
  _genId(prefix = '') {
    return prefix + '_' + Math.random().toString(36).slice(2, 9).toUpperCase();
  }

  _genRoomCode() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let code = '';
    for (let i = 0; i < 6; i++) code += chars[Math.floor(Math.random() * chars.length)];
    return code;
  }

  // ── Profil ────────────────────────────────────────────────────────────────
  saveProfile(name) {
    this.playerName = name.trim();
    localStorage.setItem('biosmart_player_name', this.playerName);
  }

  getProfile() {
    return { id: this.playerId, name: this.playerName, stats: this._loadStats() };
  }

  _loadStats() {
    try {
      const raw = localStorage.getItem('biosmart_stats_v2');
      return raw ? JSON.parse(raw) : { played: 0, wins: 0, losses: 0, asParazit: 0, asHujayra: 0 };
    } catch { return { played: 0, wins: 0, losses: 0, asParazit: 0, asHujayra: 0 }; }
  }

  updateStats(won, role) {
    const s = this._loadStats();
    s.played++;
    if (won) s.wins++; else s.losses++;
    if (['parazit','boshliq','bakteriya','virus','zamburug'].includes(role)) s.asParazit++;
    else s.asHujayra++;
    localStorage.setItem('biosmart_stats_v2', JSON.stringify(s));
  }

  // ── Xona yaratish ────────────────────────────────────────────────────────
  async createRoom(hostName, config = {}) {
    this.saveProfile(hostName);
    const code = this._genRoomCode();
    this.roomId = code;

    const roomData = {
      code,
      hostId:    this.playerId,
      status:    'lobby',
      round:     0,
      config: {
        advancedRoles:    config.advancedRoles    || false,
        includeImmunit:   config.includeImmunit   !== false,
        includeLimfotsit: config.includeLimfotsit !== false,
        maxPlayers:       config.maxPlayers       || 15,
      },
      players: {
        [this.playerId]: {
          id:       this.playerId,
          name:     hostName.trim(),
          alive:    true,
          ready:    false,
          isHost:   true,
          joinedAt: Date.now(),
          role:     null,
          votes:    0,
          protected:false,
          online:   true,
        }
      },
      nightActions: {},
      logs:    [],
      winner:  null,
      createdAt: Date.now(),
    };

    await window.db.ref(`rooms/${code}`).set(roomData);
    await window.db.ref(`rooms/${code}/players/${this.playerId}/online`).set(true);
    window.db.ref(`rooms/${code}/players/${this.playerId}/online`).onDisconnect().set(false);

    return code;
  }

  // ── Xonaga qo'shilish ────────────────────────────────────────────────────
  async joinRoom(code, playerName) {
    this.saveProfile(playerName);
    code = code.toUpperCase().trim();
    this.roomId = code;

    const snap = await window.db.ref(`rooms/${code}`).once('value');
    if (!snap.exists()) throw new Error('Xona topilmadi: ' + code);

    const room = snap.val();
    if (room.status !== 'lobby') throw new Error("O'yin allaqachon boshlangan!");

    const playerCount = Object.keys(room.players || {}).length;
    if (playerCount >= (room.config.maxPlayers || 15)) throw new Error("Xona to'lgan!");

    const existing = room.players?.[this.playerId];

    await window.db.ref(`rooms/${code}/players/${this.playerId}`).set({
      id:       this.playerId,
      name:     playerName.trim(),
      alive:    existing?.alive ?? true,
      ready:    false,
      isHost:   room.hostId === this.playerId,
      joinedAt: existing?.joinedAt ?? Date.now(),
      role:     existing?.role ?? null,
      votes:    0,
      protected:false,
      online:   true,
    });

    window.db.ref(`rooms/${code}/players/${this.playerId}/online`).onDisconnect().set(false);
    return room;
  }

  // ── Real-time tinglovchilar ───────────────────────────────────────────────
  listenRoom(onUpdate) {
    // Eski tinglovchilarni to'xtatish
    this._listeners.forEach(({ ref }) => ref.off());
    this._listeners = [];

    const ref = window.db.ref(`rooms/${this.roomId}`);
    ref.on('value', snap => {
      if (snap.exists()) onUpdate(snap.val());
    });
    this._listeners.push({ ref });
  }

  stopListening() {
    this._listeners.forEach(({ ref }) => ref.off());
    this._listeners = [];
  }

  // ── Xona amaliyotlari ────────────────────────────────────────────────────
  async setReady(ready = true) {
    await window.db.ref(`rooms/${this.roomId}/players/${this.playerId}/ready`).set(ready);
  }

  async startGame(players, config) {
    const roles = this._distributeRoles(players, config);
    const updates = {};
    players.forEach((p, i) => {
      updates[`rooms/${this.roomId}/players/${p.id}/role`]  = roles[i];
      updates[`rooms/${this.roomId}/players/${p.id}/alive`] = true;
      updates[`rooms/${this.roomId}/players/${p.id}/votes`] = 0;
    });
    updates[`rooms/${this.roomId}/status`] = 'roles';
    updates[`rooms/${this.roomId}/round`]  = 1;
    await window.db.ref().update(updates);
    await this.addLog('system', `🧬 O'yin boshlandi! ${players.length} o'yinchi tayyor.`);
  }

  async advanceToNight() {
    await window.db.ref(`rooms/${this.roomId}`).update({
      status:       'night',
      nightActions: {},
    });
    await this.addLog('phase', `🌙 Kecha bosqichi — infeksiya vaqti`);
  }

  async advanceToDay() {
    await window.db.ref(`rooms/${this.roomId}/status`).set('day');
    await this.addLog('phase', '☀️ Tahlil bosqichi boshlandi');
  }

  async advanceToVote() {
    const snap = await window.db.ref(`rooms/${this.roomId}/players`).once('value');
    const updates = {};
    snap.forEach(child => {
      updates[`rooms/${this.roomId}/players/${child.key}/votes`] = 0;
    });
    updates[`rooms/${this.roomId}/status`]            = 'vote';
    updates[`rooms/${this.roomId}/votes`]             = null; // Eski ovozlarni tozalash
    updates[`rooms/${this.roomId}/voteResolvedAt`]    = null;
    await window.db.ref().update(updates);
    await this.addLog('phase', `🗳️ Ovoz berish boshlandi`);
  }

  async submitNightAction(actionType, targetId) {
    await window.db.ref(`rooms/${this.roomId}/nightActions/${actionType}`).set({
      targetId,
      actorId: this.playerId,
      ts:      Date.now(),
    });
  }

  async submitVote(targetId) {
    await window.db.ref(`rooms/${this.roomId}/votes/${this.playerId}`).set(targetId);
  }

  // ── Kecha natijasini hisoblash ────────────────────────────────────────────
  async resolveNight(room) {
    if (!this.isHost(room)) return null;

    const { nightActions, players } = room;
    const playerArr = Object.values(players);
    const result    = { killed: null, saved: false, killedSecond: null };

    // Himoyani reset
    const updates = {};
    playerArr.forEach(p => {
      updates[`rooms/${this.roomId}/players/${p.id}/protected`] = false;
    });

    // Immunitet
    if (nightActions?.immunitet?.targetId) {
      const tid = nightActions.immunitet.targetId;
      updates[`rooms/${this.roomId}/players/${tid}/protected`] = true;
      const savedName = playerArr.find(p => p.id === tid)?.name;
      result.savedId = tid;
      await this.addLog('immunitet', `💊 Immunitet ${savedName}ni himoya qildi`);
    }

    await window.db.ref().update(updates);

    // Yangilangan holat
    const freshSnap = await window.db.ref(`rooms/${this.roomId}/players`).once('value');
    const freshArr  = Object.values(freshSnap.val() || {});

    // Parazit hujumi
    if (nightActions?.parazit?.targetId) {
      const tid    = nightActions.parazit.targetId;
      const target = freshArr.find(p => p.id === tid);
      if (target?.protected) {
        result.saved = true;
        await this.addLog('immunitet', `🛡️ ${target.name} himoyalangan edi — hujum bekor!`);
      } else if (target) {
        await window.db.ref(`rooms/${this.roomId}/players/${tid}/alive`).set(false);
        result.killed = target;
        await this.addLog('parazit', `☠️ ${target.name} infeksiyalandi va halok bo'ldi`);

        // Virus: ikkinchi hujum
        const hasVirus = freshArr.find(p => p.role === 'virus' && p.alive);
        if (hasVirus) {
          const others = freshArr.filter(p =>
            p.alive && p.id !== tid && !['parazit','boshliq','bakteriya','virus','zamburug'].includes(p.role)
          );
          if (others.length > 0) {
            const second = others[Math.floor(Math.random() * others.length)];
            if (!second.protected) {
              await window.db.ref(`rooms/${this.roomId}/players/${second.id}/alive`).set(false);
              result.killedSecond = second;
              await this.addLog('parazit', `🦠 Virus ${second.name}ni ham infeksiyaladi!`);
            }
          }
        }
      }
    } else {
      await this.addLog('system', '😴 Parazit bu kecha hujum qilmadi');
    }

    // Limfotsit
    if (nightActions?.limfotsit?.targetId) {
      const tid     = nightActions.limfotsit.targetId;
      const checked = freshArr.find(p => p.id === tid);
      if (checked) {
        const isPar = ['parazit','boshliq','bakteriya','virus','zamburug'].includes(checked.role);
        const limfId = nightActions.limfotsit.actorId;
        await window.db.ref(`rooms/${this.roomId}/privateData/${limfId}/inspectResult`).set({
          player: { id: checked.id, name: checked.name, role: checked.role },
          isParazit: isPar,
        });
        await this.addLog('limfotsit', `🔬 Limfotsit tekshiruv o'tkazdi`);
      }
    }

    // Hozirgi tirik o'yinchilar ro'yxati (o'lganlar hisobga olingan holda)
    const finalSnap = await window.db.ref(`rooms/${this.roomId}/players`).once('value');
    const finalArr  = Object.values(finalSnap.val() || {}).filter(p => p.alive);

    // G'alaba sharti tekshiruvi
    const winner = this._checkWin(finalArr);
    if (winner) {
      await this._endGame(winner);
    } else {
      // Natija ekrani, keyin avtomatik kunduz
      await window.db.ref(`rooms/${this.roomId}/lastNightResult`).set({
        killed:       result.killed       ? { id: result.killed.id, name: result.killed.name, role: result.killed.role } : null,
        killedSecond: result.killedSecond ? { id: result.killedSecond.id, name: result.killedSecond.name, role: result.killedSecond.role } : null,
        saved:        result.saved,
        savedId:      result.savedId || null,
        ts:           Date.now(),
      });
      await window.db.ref(`rooms/${this.roomId}/status`).set('result');
    }

    return result;
  }

  // ── Ovoz natijasini hisoblash ────────────────────────────────────────────
  async resolveVotes(room) {
    if (!this.isHost(room)) return { eliminated: null };

    // Ikki marta ishlamasligi uchun lock
    const lockRef = window.db.ref(`rooms/${this.roomId}/voteResolvedAt`);
    const lockSnap = await lockRef.once('value');
    if (lockSnap.val()) return { eliminated: null }; // allaqachon hal qilingan
    await lockRef.set(Date.now());

    const { votes, players } = room;
    if (!votes) {
      await this._nextRoundOrEnd(room);
      return { eliminated: null };
    }

    const playerArr  = Object.values(players).filter(p => p.alive);
    const voteCounts = {};
    playerArr.forEach(p => { voteCounts[p.id] = 0; });
    Object.values(votes).forEach(targetId => {
      if (voteCounts[targetId] !== undefined) voteCounts[targetId]++;
    });

    // Zamburug' effekti
    let shuffled = false;
    const zamburug = playerArr.find(p => p.role === 'zamburug' && p.alive);
    if (zamburug) {
      const ids  = Object.keys(voteCounts);
      const maxV = Math.max(...Object.values(voteCounts));
      const leader = playerArr.find(p => voteCounts[p.id] === maxV);
      const others = playerArr.filter(p => p.id !== leader?.id);
      if (leader && others.length > 0) {
        const rnd = others[Math.floor(Math.random() * others.length)];
        [voteCounts[leader.id], voteCounts[rnd.id]] = [voteCounts[rnd.id], voteCounts[leader.id]];
        shuffled = true;
        await this.addLog('zamburug', "🍄 Zamburug' ovozlarni aralashtirdi!");
      }
    }

    const maxVotes   = Math.max(...Object.values(voteCounts));
    const candidates = playerArr.filter(p => voteCounts[p.id] === maxVotes && maxVotes > 0);

    let eliminated = null;
    if (candidates.length === 1) {
      eliminated = candidates[0];
      await window.db.ref(`rooms/${this.roomId}/players/${eliminated.id}/alive`).set(false);
      await this.addLog('vote', `🗳️ ${eliminated.name} ovoz bilan chiqarildi (Rol: ${this._roleName(eliminated.role)})`);
    } else {
      await this.addLog('vote', '🤝 Ovozlar teng — hech kim chiqarilmadi');
    }

    // Ovozlarni tozalash
    await window.db.ref(`rooms/${this.roomId}/votes`).remove();

    // Yangilangan tirik o'yinchilar
    const aliveSnap = await window.db.ref(`rooms/${this.roomId}/players`).once('value');
    const aliveAfter = Object.values(aliveSnap.val() || {}).filter(p => p.alive);

    // G'alaba tekshiruvi
    const winner = this._checkWin(aliveAfter);
    if (winner) {
      await this._endGame(winner);
    } else {
      await this._nextRound(room);
    }

    return { eliminated, shuffled };
  }

  // ── Keyingi turga o'tish ─────────────────────────────────────────────────
  async _nextRound(room) {
    const newRound = (room.round || 1) + 1;
    await window.db.ref(`rooms/${this.roomId}`).update({
      status:       'night',
      round:        newRound,
      nightActions: {},
      voteResolvedAt: null,
    });
    await this.addLog('phase', `🌙 ${newRound}-tur: Kecha boshlandi`);
  }

  // ── G'alaba sharti ────────────────────────────────────────────────────────
  /**
   * O'yin FAQAT bir tomonning BARCHA o'yinchilari chiqib ketganda tugaydi.
   * Parazitlar = 0  → Hujayralar g'alaba (barcha parazitlar yo'q qilindi)
   * Hujayralar = 0  → Parazitlar g'alaba (barcha hujayralar zararlandi)
   */
  _checkWin(alivePlayers) {
    const parazits   = alivePlayers.filter(p => ['parazit','boshliq','bakteriya','virus','zamburug'].includes(p.role)).length;
    const hujayralar = alivePlayers.filter(p => !['parazit','boshliq','bakteriya','virus','zamburug'].includes(p.role)).length;

    if (parazits   === 0) return 'hujayra';  // Barcha parazitlar yo'q qilindi
    if (hujayralar === 0) return 'parazit';  // Barcha hujayralar zararlandi
    return null;                              // O'yin davom etadi
  }

  async _endGame(winner) {
    const msg = winner === 'parazit'
      ? "🦠 Parazitlar g'alaba qozondi!"
      : "💪 Hujayralar g'alaba qozondi!";
    await this.addLog('system', msg);
    await window.db.ref(`rooms/${this.roomId}`).update({
      status: 'gameover',
      winner,
    });
  }

  // ── Rollarni taqsimlash ───────────────────────────────────────────────────
  /**
   * O'yinchilar soniga qarab aniq rol taqsimoti:
   *  3  → 1P  1H  1I
   *  4  → 2P  1H  1I        (boshliq + virus)
   *  5  → 2P  2H  1I
   *  6  → 2P  3H  1I
   *  7  → 3P  2H  1I  1L
   *  8  → 3P  3H  1I  1L
   *  9  → 3P  4H  1I  1L   (aslida 4+5 = 3p 5h 1i 1l — lekin 9=3p 4h 1i 1l)
   * 10  → 4P  4H  1I  1L
   * 11+ → 4P  nH  1I  1L   (qolgan barchasi hujayra)
   *
   * Parazit rollari tartibi (2P dan):
   *   boshliq, virus, bakteriya, zamburug, boshliq, virus, ...
   */
  _distributeRoles(players, config) {
    const count = players.length;
    const roles = [];

    // Aniq jadval
    const TABLE = {
      3:  { p: 1, h: 1, i: 1, l: 0 },
      4:  { p: 2, h: 1, i: 1, l: 0 },
      5:  { p: 2, h: 2, i: 1, l: 0 },
      6:  { p: 2, h: 3, i: 1, l: 0 },
      7:  { p: 3, h: 2, i: 1, l: 1 },
      8:  { p: 3, h: 3, i: 1, l: 1 },
      9:  { p: 3, h: 4, i: 1, l: 1 },
      10: { p: 4, h: 4, i: 1, l: 1 },
    };

    let dist;
    if (count <= 10) {
      dist = TABLE[count] || TABLE[3];
    } else {
      // 11 dan 20 gacha: 4P 1I 1L, qolgan barchasi H
      dist = { p: 4, i: 1, l: 1, h: count - 6 };
    }

    // Immunitet/Limfotsit sozlamalarini hurmat qilish
    const useImmunit   = config.includeImmunit   !== false && dist.i > 0;
    const useLimfotsit = config.includeLimfotsit !== false && dist.l > 0;

    // Parazit rollari ketma-ketligi: boshliq, virus, bakteriya, zamburug, ...
    const PARAZIT_SEQUENCE = ['boshliq', 'virus', 'bakteriya', 'zamburug'];
    for (let i = 0; i < dist.p; i++) {
      if (dist.p === 1) {
        roles.push('parazit');          // 1 parazit bo'lsa oddiy parazit
      } else {
        roles.push(PARAZIT_SEQUENCE[i % PARAZIT_SEQUENCE.length]);
      }
    }

    if (useImmunit)   roles.push('immunitet');
    if (useLimfotsit) roles.push('limfotsit');

    // Immunitet/Limfotsit o'chirilgan bo'lsa ortiqcha rolni H bilan to'ldirish
    const specialCount = roles.length;
    const hujayraSoni  = count - specialCount;
    for (let i = 0; i < hujayraSoni; i++) roles.push('hujayra');

    // Fisher-Yates shuffle
    for (let i = roles.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [roles[i], roles[j]] = [roles[j], roles[i]];
    }
    return roles;
  }

  _roleName(roleId) {
    const names = {
      parazit:   'Parazit',
      boshliq:   'Parazit Boshliq',
      bakteriya: 'Bakteriya',
      virus:     'Virus',
      zamburug:  "Zamburug'",
      immunitet: 'Immunitet',
      limfotsit: 'Limfotsit',
      hujayra:   'Hujayra',
    };
    return names[roleId] || roleId;
  }

  async addLog(type, message) {
    const entry = { type, message, ts: Date.now() };
    await window.db.ref(`rooms/${this.roomId}/logs`).push(entry);
  }

  async deleteRoom() {
    if (this.roomId) {
      await window.db.ref(`rooms/${this.roomId}`).remove();
    }
  }

  isHost(room) {
    return room?.hostId === this.playerId;
  }

  getMyPlayer(room) {
    return room?.players?.[this.playerId] || null;
  }

  async readPrivateData() {
    const snap = await window.db.ref(`rooms/${this.roomId}/privateData/${this.playerId}`).once('value');
    return snap.val();
  }
}

window.RoomManager = RoomManager;
