/**
 * BIOSMART Online — main.js (TUZATILGAN v2.1)
 * Asosiy ilova oqimi, Firebase real-time tinglovchilar
 */
'use strict';

(function () {
  let rm = null;
  let ui = null;
  let _nightCheckTimeout   = null;
  let _voteResolving       = false;  // ikki marta resolveVotes chaqirilishini oldini oladi
  let _currentStatus       = null;   // joriy status — keraksiz re-renderlarni bloklash

  // ── Ilova ishga tushishi ──────────────────────────────────────────────────
  document.addEventListener('DOMContentLoaded', () => {
    if (typeof firebase === 'undefined' || !window.db) {
      showFatalError('Firebase ulanmadi. firebase-config.js ni tekshiring.');
      return;
    }

    rm = new RoomManager();
    ui = new UIController(rm);

    _bindLandingEvents();
    ui.renderLanding();
  });

  // ── Landing tugmalari ────────────────────────────────────────────────────
  function _bindLandingEvents() {
    document.getElementById('btn-create-room')?.addEventListener('click', async () => {
      const name = document.getElementById('input-player-name')?.value?.trim();
      if (!name) { toast('Ismingizni kiriting!', 'warn'); return; }
      try {
        setLoading(true, 'Xona yaratilmoqda...');
        const code = await rm.createRoom(name);
        setLoading(false);
        toast(`✅ Xona yaratildi: ${code}`, 'success');
        _enterRoom(code);
      } catch (err) {
        setLoading(false);
        toast('Xona yaratishda xato: ' + err.message, 'error');
      }
    });

    document.getElementById('btn-join-room')?.addEventListener('click', async () => {
      const name = document.getElementById('input-player-name')?.value?.trim();
      const code = document.getElementById('input-room-code')?.value?.trim().toUpperCase();
      if (!name) { toast('Ismingizni kiriting!', 'warn'); return; }
      if (!code || code.length !== 6) { toast('6 ta belgili xona kodini kiriting!', 'warn'); return; }
      try {
        setLoading(true, "Xonaga qo'shilmoqda...");
        await rm.joinRoom(code, name);
        setLoading(false);
        _enterRoom(code);
      } catch (err) {
        setLoading(false);
        toast("Xonaga qo'shilishda xato: " + err.message, 'error');
      }
    });

    // Qoidalar tugmasi
    document.getElementById('btn-show-rules')?.addEventListener('click', () => {
      ui.renderRules();
    });

    // So'roqcha (hint) tugmalar
    _bindHintBtn('hint-create', 'hint-create-popup');
    _bindHintBtn('hint-join',   'hint-join-popup');
  }

  function _bindHintBtn(btnId, popupId) {
    const btn    = document.getElementById(btnId);
    const popup  = document.getElementById(popupId);
    if (!btn || !popup) return;

    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const isOpen = popup.classList.contains('show');
      // Barcha popup larni yopish
      document.querySelectorAll('.hint-popup').forEach(p => p.classList.remove('show'));
      if (!isOpen) popup.classList.add('show');
    });
  }

  // Tashqarida bosganda hint larni yopish
  document.addEventListener('click', () => {
    document.querySelectorAll('.hint-popup').forEach(p => p.classList.remove('show'));
  });

  // ── Xonaga kirish va real-time tinglash ───────────────────────────────────
  function _enterRoom(code) {
    rm.roomId = code;
    _currentStatus = null;
    _voteResolving = false;

    rm.listenRoom(async (room) => {
      ui._updateHeader(room);
      _updateOnlineDot(room);

      const status = room.status;

      // Bir xil statusda keraksiz re-renderlarni kamaytirish
      // (lekin ba'zi ekranlar uchun har doim yangilanishi kerak)
      const alwaysRender = ['lobby', 'result', 'vote'];
      if (status === _currentStatus && !alwaysRender.includes(status)) return;
      _currentStatus = status;

      // Timeout larni tozalash
      if (_nightCheckTimeout) { clearTimeout(_nightCheckTimeout); _nightCheckTimeout = null; }

      if (status === 'lobby') {
        _voteResolving = false;
        ui.renderLobby(room);

      } else if (status === 'roles') {
        ui.renderRoleReveal(room);
        // Host: 4 sekunddan keyin kechaga o'tish
        if (rm.isHost(room)) {
          _nightCheckTimeout = setTimeout(async () => {
            await rm.advanceToNight();
          }, 4000);
        }

      } else if (status === 'night') {
        ui._actionDone = false;
        ui._privateData = await rm.readPrivateData();
        ui.renderNight(room);
        // Host: barcha harakatlar bo'lganini kuzatish
        _scheduleNightCheck(room);

      } else if (status === 'result') {
        ui._privateData = await rm.readPrivateData();
        ui.renderNightResult(room);
        // Host: 5 sekunddan keyin avtomatik kunduz bosqichiga o'tish
        if (rm.isHost(room)) {
          _nightCheckTimeout = setTimeout(async () => {
            await rm.advanceToDay();
          }, 5000);
        }

      } else if (status === 'day') {
        ui._privateData = await rm.readPrivateData();
        ui.renderDay(room);

      } else if (status === 'vote') {
        // Faqat birinchi render yoki yangi tur boshida
        if (!ui._voteDone) {
          ui.renderVote(room);
        }
        // Host: barcha ovozlar to'planganini kuzatish
        if (rm.isHost(room) && !_voteResolving) {
          const alive     = Object.values(room.players || {}).filter(p => p.alive);
          const voteCount = Object.keys(room.votes || {}).length;
          if (voteCount >= alive.length) {
            _voteResolving = true;
            await rm.resolveVotes(room);
          }
        }

      } else if (status === 'gameover') {
        ui.renderGameOver(room);
      }
    });
  }

  // ── Kecha tugashini rejalashtirilgan tekshirish ────────────────────────────
  function _scheduleNightCheck(room) {
    if (!rm.isHost(room)) return;
    _nightCheckTimeout = setTimeout(() => _checkNightComplete(room), 2000);
  }

  async function _checkNightComplete(room) {
    if (!rm.isHost(room)) return;

    // Eng yangi holatni Firebase dan o'qiymiz
    const snap  = await window.db.ref(`rooms/${room.code}`).once('value');
    const fresh = snap.val();
    if (!fresh || fresh.status !== 'night') return;

    const config   = fresh.config || {};
    const alive    = Object.values(fresh.players || {}).filter(p => p.alive);
    const actions  = fresh.nightActions || {};

    const hasParazit   = alive.some(p => isParazit(p.role) && p.role !== 'zamburug');
    const hasImmunit   = alive.some(p => p.role === 'immunitet') && config.includeImmunit !== false;
    const hasLimfotsit = alive.some(p => p.role === 'limfotsit') && config.includeLimfotsit !== false;

    const parazitDone   = !hasParazit   || actions.parazit;
    const immunitDone   = !hasImmunit   || actions.immunitet;
    const limfotsitDone = !hasLimfotsit || actions.limfotsit;

    if (parazitDone && immunitDone && limfotsitDone) {
      await rm.resolveNight(fresh);
    } else {
      // 3 sekunddan keyin qayta tekshir
      _nightCheckTimeout = setTimeout(() => _checkNightComplete(fresh), 3000);
    }
  }

  // ── Online indikator ──────────────────────────────────────────────────────
  function _updateOnlineDot(room) {
    const online = Object.values(room.players || {}).filter(p => p.online !== false).length;
    const el = document.getElementById('online-count');
    if (el) el.textContent = online;
  }

  // ── Global yordamchilar ───────────────────────────────────────────────────
  function setLoading(on, msg = '') {
    const overlay = document.getElementById('loading-overlay');
    const txt     = document.getElementById('loading-text');
    if (overlay) overlay.classList.toggle('active', on);
    if (txt) txt.textContent = msg;
  }

  function toast(msg, type = 'info') {
    const tc = document.getElementById('toast-container');
    if (!tc) return;
    const t = document.createElement('div');
    t.className = `toast toast-${type}`;
    t.textContent = msg;
    tc.appendChild(t);
    requestAnimationFrame(() => t.classList.add('show'));
    setTimeout(() => { t.classList.remove('show'); setTimeout(() => t.remove(), 400); }, 3000);
  }

  function showFatalError(msg) {
    document.body.innerHTML = `
      <div style="display:flex;align-items:center;justify-content:center;min-height:100vh;
                  background:#030a0f;color:#ff4757;font-family:monospace;text-align:center;padding:20px">
        <div>
          <div style="font-size:4rem">⚠️</div>
          <h2>Xato</h2>
          <p>${msg}</p>
          <p style="color:#7ab8cc;margin-top:16px;font-size:0.85rem">
            public/js/firebase-config.js faylini to'ldiring va sahifani yangilang.
          </p>
        </div>
      </div>`;
  }

  window.copyRoomCode = function () {
    const code = document.getElementById('room-code-display')?.textContent;
    if (!code) return;
    navigator.clipboard?.writeText(code).then(() => toast('📋 Kod nusxalandi!', 'success'));
  };

  window.toast      = toast;
  window.setLoading = setLoading;

})();
