/**
 * BIOSMART — Firebase Config (TO'G'RI versiya)
 * Region: United States (us-central1)
 */

const firebaseConfig = {
  apiKey:            "AIzaSyDzrL3C4-51vwd85o7kEZZpjDqd-OGOLjc",
  authDomain:        "online-biosmart.firebaseapp.com",
  projectId:         "online-biosmart",
  storageBucket:     "online-biosmart.firebasestorage.app",
  messagingSenderId: "473780394649",
  appId:             "1:473780394649:web:4f0a7ee20659d5aa4cf608",
  measurementId:     "G-X5MPV81C2P",

  // ✅ US region uchun to'g'ri URL (Europe emas!)
  databaseURL: "https://online-biosmart-default-rtdb.firebaseio.com"
};

if (typeof firebase === 'undefined') {
  console.error('❌ Firebase SDK yuklanmadi!');
} else {
  try {
    if (!firebase.apps.length) {
      firebase.initializeApp(firebaseConfig);
    }
    window.db = firebase.database();

    window.db.ref('.info/connected').on('value', (snap) => {
      if (snap.val() === true) {
        console.log('✅ Firebase Realtime Database ulandi!');
      } else {
        console.warn('⚠️ DB ga ulanmadi');
      }
    });

    console.log('🔥 Firebase OK');
  } catch (err) {
    console.error('❌ Firebase xatosi:', err.message);
  }
}
